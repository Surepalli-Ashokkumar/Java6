let a:number;
a=56;

let b:number=12;

let fname:string="Nikunj Soni";

console.log(a+b);

console.log(fname);


function test(num1:number,num2:number):number{
    return num1+num2;
}

console.log(test(2,3));