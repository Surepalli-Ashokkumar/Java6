var a;
a = 56;
var b = 12;
var fname = "Nikunj Soni";
console.log(a + b);
console.log(fname);
function test(num1, num2) {
    return num1 + num2;
}
console.log(test(2, 3));
